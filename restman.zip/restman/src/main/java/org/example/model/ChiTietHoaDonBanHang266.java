package org.example.model;

public class ChiTietHoaDonBanHang266 {
    private int id;
    private int soLuong;
    private float giaMonAn;
    private int hoaDonBanHangID;
    private int monAnID;
    private String monAn;

    public String getMonAn() {
        return monAn;
    }

    public void setMonAn(String monAn) {
        this.monAn = monAn;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public float getGiaMonAn() {
        return giaMonAn;
    }

    public void setGiaMonAn(float giaMonAn) {
        this.giaMonAn = giaMonAn;
    }

    public int getHoaDonBanHangID() {
        return hoaDonBanHangID;
    }

    public void setHoaDonBanHangID(int hoaDonBanHangID) {
        this.hoaDonBanHangID = hoaDonBanHangID;
    }

    public int getMonAnID() {
        return monAnID;
    }

    public void setMonAnID(int monAnID) {
        this.monAnID = monAnID;
    }
}
