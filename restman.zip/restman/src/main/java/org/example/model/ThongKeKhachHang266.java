package org.example.model;

public class ThongKeKhachHang266 {
    private int khachHangId;
    private String kHTenDangNhap;
    private String khEmail;
    private String khPhone;
    private String khDiaChi;
    private float tongChiTieu;
    private int soLanDatMon;

    public int getSoLanDatMon() {
        return soLanDatMon;
    }

    public void setSoLanDatMon(int soLanDatMon) {
        this.soLanDatMon = soLanDatMon;
    }

    public int getKhachHangId() {
        return khachHangId;
    }

    public void setKhachHangId(int khachHangId) {
        this.khachHangId = khachHangId;
    }

    public String getkHTenDangNhap() {
        return kHTenDangNhap;
    }

    public void setkHTenDangNhap(String kHTenDangNhap) {
        this.kHTenDangNhap = kHTenDangNhap;
    }

    public String getKhEmail() {
        return khEmail;
    }

    public void setKhEmail(String khEmail) {
        this.khEmail = khEmail;
    }

    public String getKhPhone() {
        return khPhone;
    }

    public void setKhPhone(String khPhone) {
        this.khPhone = khPhone;
    }

    public String getKhDiaChi() {
        return khDiaChi;
    }

    public void setKhDiaChi(String khDiaChi) {
        this.khDiaChi = khDiaChi;
    }

    public float getTongChiTieu() {
        return tongChiTieu;
    }

    public void setTongChiTieu(float tongChiTieu) {
        this.tongChiTieu = tongChiTieu;
    }
}
